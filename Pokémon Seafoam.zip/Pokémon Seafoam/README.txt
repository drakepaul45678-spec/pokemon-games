{[OVERVIEW]}
This is just a quick highlight of some of the game's basics. Credits, known bugs, etc. 

[{Controls]}
Now, about controls - the default controls (and the ones stated in the game) are your arrow keys, Z (A button), X (B button), 
Enter (start), shift (select). However, this will not be the case depending on what the defaults are for your emulator buttons.

{[KNOWN BUGS]}
1. Kabuto & Gastly in Bandit's Gorge - these events like to vanish whenever they feel like it. 
2. Occasional inability to interact with events - just try switching around maps or getting a game over. This should reset your ability to talk to events. 
3. Occasional invincibility - I added multiple checks throughout map transfers in the game to reset the damage counter, should you run into this. 
4. Occasional invisible doors - some of the time a door that should be blocked will not show the blocked door graphic until you leave the room and come back.

[CREDITS]
[Audio]
Tomas Danko
krümel (crumb)#0723
Ember#1765 / DeerTears
Tronimal
Rulz

[Font]
DigiDuncan

[Overworld Sprites]
Clara 
Princess Phoenix 
Lunar Dusk
NoodlesButt
Mageker

MissingLukey
help-14
Kymoyonian
cSc-A7X
2and2makes5
Pokegirl4ever
Fernandojl 
Silver-Skies 
TyranitarDark 
Getsuei-H 
Kid1513 
Milomilotic11 

Kyt666 
kdiamo11 
Chocosrawlooid 
Syledude 
Gallanty 
Gizamimi-Pichu 
2and2makes5
Zyon17
LarryTurbo 
spritesstealer
Larry Turbo
SageDeoxys
Wolfang62
Mister Mike

[Overworld Tiles]
airshuffler
davias
frenchorange
gamenerdadvance
jermungandr
KOOLKID67890
Pulse Commander
Ragey
RhinoKneel
Ekat
Heartlessdragoon
Vurtax
RPG Maker 2003
Aveontrainer

[Platformer Tiles]
Omega
Randomtalkingbush
jdaster64
Tetra Vega
Raccoon Sam
DrSchnaps
ShadeDBZ
Badbatman3

[Misc Graphics]
Sciz
Mr. C
Bean
Doomdragon
Ryan914
MajinPiccolo
Jackster
Previous
Jigglypuffgirl
C1994
jdaster64
French Orange
Polar Koala
JappaWakka
Nemu

[GB Studio Tutorials & Scripts]
Pixel Pete
Robert Doman

[GB Studio]
Chris Maltby (rulz)

[Playtestesters]
Michael
Samdeman123124
FoxOwl